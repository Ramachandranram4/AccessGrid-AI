"use client";

import { useEffect } from "react";
import { divIcon } from "leaflet";
import { MapContainer, TileLayer, Polyline, Circle, Marker, Popup, useMap } from "react-leaflet";
import type { AccessibilityMode, BarrierItem, DestinationOption } from "@/types/accessibility";

type Props = {
  mode: AccessibilityMode;
  barriers: BarrierItem[];
  destination: DestinationOption;
  currentLocation: [number, number];
  routePath: [number, number][];
};

const MODE_COLORS: Record<AccessibilityMode, string> = {
  blind: "#28ffc1",
  wheelchair: "#51b7ff",
  elderly: "#d8ffa7",
};


const severityColor = (severity: BarrierItem["severity"]) => {
  if (severity === "safe") return "#38f4b6";
  if (severity === "caution") return "#ffca64";
  return "#ff5478";
};

const barrierEmoji: Record<string, string> = {
  "blocked ramp": "🚫",
  "broken sidewalk": "🧱",
  "unsafe crossing": "⚠️",
  "construction barrier": "🚧",
  "road damage": "🕳️",
  "obstacle detected": "🧍",
  "safe path aid": "✅",
};

const destinationEmoji: Record<string, string> = {
  pharmacy: "💊",
  hospital: "🏥",
  metro: "🚇",
  park: "🌳",
};

const destinationSymbol = (destination: DestinationOption) => {
  const text = `${destination.label} ${destination.kind}`.toLowerCase();
  if (text.includes("pharmacy") || text.includes("drugstore")) return destinationEmoji.pharmacy;
  if (text.includes("hospital") || text.includes("clinic")) return destinationEmoji.hospital;
  if (text.includes("metro") || text.includes("station")) return destinationEmoji.metro;
  if (text.includes("park") || text.includes("garden")) return destinationEmoji.park;
  return "📍";
};

const makeEmojiIcon = (emoji: string, color: string, size = 40) =>
  divIcon({
    className: "",
    html: `
      <div style="
        width:${size}px;
        height:${size}px;
        border-radius:9999px;
        display:flex;
        align-items:center;
        justify-content:center;
        background:rgba(6,15,28,0.84);
        border:1px solid ${color};
        box-shadow:0 0 18px ${color}66, inset 0 0 20px rgba(255,255,255,0.08);
        font-size:${Math.round(size * 0.46)}px;
        backdrop-filter:blur(8px);
      ">${emoji}</div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2],
  });

function RouteCamera({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();

  useEffect(() => {
    map.flyTo(center, zoom, { animate: true, duration: 1.5 });
  }, [center, map, zoom]);

  return null;
}

function MapControlCleaner() {
  const map = useMap();

  useEffect(() => {
    const mapContainer = map.getContainer();

    const removeNorthControl = () => {
      const elements = Array.from(mapContainer.querySelectorAll("*"));

      for (const element of elements) {
        if (!(element instanceof HTMLElement)) {
          continue;
        }

        const className = element.className.toLowerCase();
        const ariaLabel = element.getAttribute("aria-label")?.toLowerCase() ?? "";
        const title = element.getAttribute("title")?.toLowerCase() ?? "";
        const text = element.textContent?.trim().toLowerCase() ?? "";
        const controlRoot = element.closest(".leaflet-control");
        const isNorthBadge =
          text === "n" &&
          element.offsetWidth <= 48 &&
          element.offsetHeight <= 48 &&
          Boolean(element.closest(".leaflet-top, .leaflet-bottom"));
        const isNorthControl =
          className.includes("north") ||
          className.includes("compass") ||
          ariaLabel.includes("north") ||
          ariaLabel.includes("compass") ||
          title.includes("north") ||
          title.includes("compass");

        if (isNorthControl || isNorthBadge) {
          (controlRoot instanceof HTMLElement ? controlRoot : element).remove();
        }
      }
    };

    removeNorthControl();

    const observer = new MutationObserver(() => {
      removeNorthControl();
    });

    observer.observe(mapContainer, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
    };
  }, [map]);

  return null;
}

export default function CityAccessibilityMap({ mode, barriers, destination, currentLocation, routePath }: Props) {
  const route = routePath.length > 1 ? routePath : [currentLocation, destination.position];

  return (
    <MapContainer
      center={currentLocation}
      zoom={16}
      scrollWheelZoom
      className="h-full w-full"
      attributionControl={false}
    >
      <RouteCamera center={destination.position} zoom={16} />
      <MapControlCleaner />

      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />

      {barriers.map((barrier) => (
        <Circle
          key={`heat-${barrier.id}`}
          center={barrier.position}
          radius={barrier.severity === "danger" ? 130 : barrier.severity === "caution" ? 95 : 70}
          pathOptions={{
            color: severityColor(barrier.severity),
            fillColor: severityColor(barrier.severity),
            fillOpacity: 0.14,
            weight: 2,
          }}
        >
          <Popup>{barrierEmoji[barrier.type] ?? "🚧"} {barrier.title}</Popup>
        </Circle>
      ))}

      <Polyline
        key={`${mode}-${destination.id}`}
        positions={route}
        pathOptions={{
          color: MODE_COLORS[mode],
          weight: 8,
          opacity: 0.94,
          lineCap: "round",
          dashArray: mode === "blind" ? "8 8" : undefined,
        }}
      />

      {barriers.map((barrier) => (
        <Marker
          key={barrier.id}
          position={barrier.position}
          icon={makeEmojiIcon(barrierEmoji[barrier.type] ?? "🚧", severityColor(barrier.severity), 42)}
        >
          <Popup>
            <div className="text-sm">
              <p className="font-semibold">
                {barrierEmoji[barrier.type] ?? "🚧"} {barrier.title}
              </p>
              <p>{barrier.type}</p>
            </div>
          </Popup>
        </Marker>
      ))}

      <Marker
        position={destination.position}
        icon={makeEmojiIcon(destinationSymbol(destination), "#79fff0", 48)}
      >
        <Popup>
          <div className="text-sm">
            <p className="font-semibold">{destinationSymbol(destination)} {destination.label}</p>
            <p>{destination.kind}</p>
            <p>{destination.hint}</p>
          </div>
        </Popup>
      </Marker>

      <Marker
        position={currentLocation}
        icon={makeEmojiIcon("🧭", "#90b9ff", 44)}
      >
        <Popup>
          <div className="text-sm">
            <p className="font-semibold">🧭 Your current location</p>
            <p>Live location used for nearby ranking and route generation</p>
          </div>
        </Popup>
      </Marker>
    </MapContainer>
  );
}
