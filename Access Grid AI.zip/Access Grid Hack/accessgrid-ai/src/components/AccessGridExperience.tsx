"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useState, type ComponentType, type FormEvent } from "react";
import type { AccessibilityMode, BarrierItem, DestinationOption, RouteSummary } from "@/types/accessibility";

type CityAccessibilityMapProps = {
  mode: AccessibilityMode;
  barriers: BarrierItem[];
  destination: DestinationOption;
  currentLocation: [number, number];
  routePath: [number, number][];
};

type Screen = "landing" | "blind" | "map" | "wheelchair" | "elderly" | "report";

type ReportCategory =
  | "broken sidewalk"
  | "blocked ramp"
  | "unsafe crossing"
  | "construction barrier"
  | "road damage"
  | "obstacle detected";

type CommunityPost = {
  id: string;
  author: string;
  message: string;
  label: string;
  tone: "safe" | "caution" | "danger";
};

type SpeechRecognitionEventLike = {
  results: ArrayLike<ArrayLike<{ transcript: string }>>;
};

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
};

type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

const featureCards = [
  "AI Voice Guidance",
  "Accessibility Routing",
  "Real-Time Obstacle Detection",
  "Community Accessibility Reports",
];

const navItems: Array<{ key: Screen; label: string }> = [
  { key: "landing", label: "Start Navigation" },
  { key: "blind", label: "Blind Mode" },
  { key: "map", label: "Accessibility Map" },
  { key: "report", label: "Report Barrier" },
  { key: "wheelchair", label: "Wheelchair" },
  { key: "elderly", label: "Elderly" },
];

const reportCategories: ReportCategory[] = [
  "broken sidewalk",
  "blocked ramp",
  "unsafe crossing",
  "construction barrier",
  "road damage",
  "obstacle detected",
];

const reportEmoji: Record<ReportCategory, string> = {
  "broken sidewalk": "🧱",
  "blocked ramp": "🚫",
  "unsafe crossing": "⚠️",
  "construction barrier": "🚧",
  "road damage": "🕳️",
  "obstacle detected": "🧍",
};

const barrierTypeEmoji: Record<string, string> = {
  "broken sidewalk": "🧱",
  "blocked ramp": "🚫",
  "unsafe crossing": "⚠️",
  "construction barrier": "🚧",
  "road damage": "🕳️",
  "obstacle detected": "🧍",
  "safe path aid": "✅",
};

const barrierSymbol = (type: string) => barrierTypeEmoji[type] ?? "🚧";

const DEFAULT_DESTINATION: DestinationOption = {
  id: "default-destination",
  label: "Destination",
  kind: "Google Places result",
  position: [19.4326, -99.1332],
  hint: "Search a destination to get a real-time route.",
};

const destinationEmoji: Record<string, string> = {
  pharmacy: "💊",
  hospital: "🏥",
  metro: "🚇",
  park: "🌳",
};

const destinationSymbol = (destination: DestinationOption) => {
  const text = `${destination.label} ${destination.kind}`.toLowerCase();
  if (text.includes("pharmacy") || text.includes("drugstore")) return destinationEmoji.pharmacy;
  if (text.includes("hospital") || text.includes("clinic")) return destinationEmoji.hospital;
  if (text.includes("metro") || text.includes("station")) return destinationEmoji.metro;
  if (text.includes("park") || text.includes("garden")) return destinationEmoji.park;
  return "📍";
};

const DEFAULT_MEXICO_LOCATION: [number, number] = [19.4326, -99.1332];

const communityToneEmoji: Record<CommunityPost["tone"], string> = {
  safe: "✅",
  caution: "⚠️",
  danger: "🚨",
};

const initialCommunityPosts: CommunityPost[] = [];

const severityStyle = {
  safe: "border-emerald-300/80 bg-emerald-400/20 text-emerald-100",
  caution: "border-yellow-300/80 bg-yellow-400/20 text-yellow-50",
  danger: "border-rose-400/90 bg-rose-500/20 text-rose-100",
};

const modeLabel: Record<AccessibilityMode, string> = {
  blind: "Blind Voice Mode",
  wheelchair: "Wheelchair Route Priority",
  elderly: "Elderly Low-Complexity Mode",
};

const categoryFromQuery = (query: string) => {
  const normalized = query.toLowerCase();
  if (normalized.includes("pharmacy") || normalized.includes("medicine") || normalized.includes("medical shop")) {
    return "pharmacy";
  }
  if (normalized.includes("hospital") || normalized.includes("clinic") || normalized.includes("medical")) {
    return "hospital";
  }
  if (normalized.includes("metro") || normalized.includes("station") || normalized.includes("transit")) {
    return "metro";
  }
  if (normalized.includes("park") || normalized.includes("garden")) {
    return "park";
  }
  return "pharmacy";
};

const distanceKm = (from: [number, number], to: [number, number]) => {
  const toRadians = (deg: number) => (deg * Math.PI) / 180;
  const earthRadius = 6371;
  const dLat = toRadians(to[0] - from[0]);
  const dLng = toRadians(to[1] - from[1]);
  const lat1 = toRadians(from[0]);
  const lat2 = toRadians(to[0]);

  const a = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return earthRadius * c;
};

export default function AccessGridExperience() {
  const [CityAccessibilityMap, setCityAccessibilityMap] = useState<ComponentType<CityAccessibilityMapProps> | null>(null);
  const [screen, setScreen] = useState<Screen>("landing");
  const [mode, setMode] = useState<AccessibilityMode>("blind");
  const [selectedDestination, setSelectedDestination] = useState<DestinationOption>(DEFAULT_DESTINATION);
  const [destinationQuery, setDestinationQuery] = useState("");
  const [hasRequestedDestination, setHasRequestedDestination] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<[number, number]>(DEFAULT_MEXICO_LOCATION);
  const [locationStatus, setLocationStatus] = useState("Detecting your current location...");
  const [liveDestinations, setLiveDestinations] = useState<DestinationOption[]>([]);
  const [routePath, setRoutePath] = useState<[number, number][]>([]);
  const [routeSummary, setRouteSummary] = useState<RouteSummary>({ distanceMeters: 0, durationSeconds: 0 });
  const [isAnalyzingDestination, setIsAnalyzingDestination] = useState(false);
  const [listening, setListening] = useState(false);
  const [speechEnabled] = useState(() => typeof window !== "undefined" && "speechSynthesis" in window);
  const [thinking, setThinking] = useState(false);
  const [conversation, setConversation] = useState<string[]>([]);
  const [barriers, setBarriers] = useState<BarrierItem[]>([]);
  const [hazardPulse, setHazardPulse] = useState(false);
  const [reportFile, setReportFile] = useState<File | null>(null);
  const [reportCategory, setReportCategory] = useState<ReportCategory>("construction barrier");
  const [reportSuccess, setReportSuccess] = useState("");
  const [aiAlert, setAiAlert] = useState("AI route assistant online.");
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>(initialCommunityPosts);
  const [communityAuthor, setCommunityAuthor] = useState("");
  const [communityMessage, setCommunityMessage] = useState("");

  const statTargets = useMemo(() => {
    return [
      { label: "Live destinations loaded", value: liveDestinations.length },
      { label: "Barriers reported", value: barriers.length },
      { label: "Community posts", value: communityPosts.length },
    ];
  }, [barriers.length, communityPosts.length, liveDestinations.length]);

  useEffect(() => {
    let isActive = true;

    void import("@/components/CityAccessibilityMap").then((module) => {
      if (isActive) {
        setCityAccessibilityMap(() => module.default);
      }
    });

    return () => {
      isActive = false;
    };
  }, []);

  const selectedDistanceKm = useMemo(() => {
    if (routeSummary.distanceMeters > 0) {
      return routeSummary.distanceMeters / 1000;
    }

    return distanceKm(currentLocation, selectedDestination.position);
  }, [currentLocation, routeSummary.distanceMeters, selectedDestination.position]);

  const nearbyMatches = useMemo(() => {
    const query = destinationQuery.trim().toLowerCase();
    const sourceDestinations = liveDestinations;

    if (!query) {
      return [];
    }

    return sourceDestinations.map((destination) => ({
      destination,
      distance: distanceKm(currentLocation, destination.position),
    }))
      .filter(({ destination }) => {
        if (!query) return true;
        const searchable = `${destination.label} ${destination.kind} ${destination.hint}`.toLowerCase();
        return searchable.includes(query);
      })
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 5);
  }, [currentLocation, destinationQuery, liveDestinations]);

  const safetyScore = useMemo(() => {
    if (mode === "wheelchair") return 92;
    if (mode === "elderly") return 95;
    return 90;
  }, [mode]);

  const routeAnalysis = useMemo(() => {
    const barrierCount = barriers.filter((barrier) => barrier.severity !== "safe").length;
    const blockedRamps = barriers.filter((barrier) => barrier.type === "blocked ramp").length;
    const roadDamage = barriers.filter((barrier) => barrier.type === "road damage").length;
    const durationMinutes = routeSummary.durationSeconds > 0 ? Math.max(1, Math.round(routeSummary.durationSeconds / 60)) : null;

    return [
      `Route optimized for ${selectedDestination.label}`,
      `${selectedDistanceKm.toFixed(2)} km from your current location`,
      durationMinutes ? `${durationMinutes} min estimated travel time` : "Travel time will appear after route generation",
      `${barrierCount} nearby challenges scanned`,
      `${blockedRamps} blocked ramp zone${blockedRamps === 1 ? "" : "s"} avoided`,
      `${roadDamage} road damage alert${roadDamage === 1 ? "" : "s"} avoided`,
    ];
  }, [barriers, routeSummary.durationSeconds, selectedDestination.label, selectedDistanceKm]);

  const safetyGuidelines = useMemo(() => {
    const baseGuidelines = [
      `Start at your current location marker and follow the glowing route to ${destinationSymbol(selectedDestination)} ${selectedDestination.label}`,
      "Stay on green route segments and avoid 🚧, 🚫, and ⚠️ challenge markers",
      "At each crossing, pause and check AI subtitle guidance before moving",
      "If a new hazard appears, wait for the route to recalculate automatically",
    ];

    if (mode === "wheelchair") {
      return [...baseGuidelines, "Use curb cuts and ramp lanes only; avoid steep sidewalk edges"];
    }

    if (mode === "elderly") {
      return [...baseGuidelines, "Take low-traffic segments slowly and use nearby rest points if needed"];
    }

    return [...baseGuidelines, "Listen to AI voice prompts for every turn and obstacle update"];
  }, [mode, selectedDestination]);

  const routeOptions = useMemo(() => {
    const dangerCount = barriers.filter((barrier) => barrier.severity === "danger").length;
    const cautionCount = barriers.filter((barrier) => barrier.severity === "caution").length;
    const modeRiskBoost = mode === "wheelchair" ? 4 : mode === "elderly" ? 3 : 2;

    const candidates = [
      {
        id: "green-corridor",
        name: "Green Access Corridor",
        distanceKm: selectedDistanceKm * 1.08,
        riskScore: Math.max(10, dangerCount * 3 + cautionCount * 2 + modeRiskBoost),
        reason: "Bypasses blocked ramps and busy crossings",
      },
      {
        id: "main-road",
        name: "Main Road Direct",
        distanceKm: selectedDistanceKm * 0.96,
        riskScore: Math.max(14, dangerCount * 4 + cautionCount * 3 + modeRiskBoost + 3),
        reason: "Fast but can include higher traffic segments",
      },
      {
        id: "shortcut-lane",
        name: "Shortcut Lane",
        distanceKm: selectedDistanceKm * 0.82,
        riskScore: Math.max(18, dangerCount * 5 + cautionCount * 3 + modeRiskBoost + 5),
        reason: "Shortest path but more challenge points",
      },
    ];

    const withScores = candidates.map((candidate) => {
      const combinedScore = candidate.distanceKm * 18 + candidate.riskScore;
      const severityPressure = dangerCount * 2 + cautionCount + modeRiskBoost;
      const difficulty =
        candidate.id === "green-corridor"
          ? "easy"
          : candidate.id === "main-road"
            ? severityPressure > 11
              ? "moderate"
              : "easy"
            : severityPressure > 13
              ? "difficult"
              : "moderate";
      return {
        ...candidate,
        combinedScore,
        difficulty,
      };
    });

    const best = withScores.reduce((acc, route) => (route.combinedScore < acc.combinedScore ? route : acc), withScores[0]);

    return {
      routes: withScores,
      best,
    };
  }, [barriers, mode, selectedDistanceKm]);

  const resolveDestination = useCallback((query: string) => {
    const normalized = query.toLowerCase().trim();

    const exact = liveDestinations.find((destination) => {
      const text = `${destination.label} ${destination.kind} ${destination.hint}`.toLowerCase();
      return text.includes(normalized);
    });

    return exact ?? liveDestinations[0] ?? selectedDestination;
  }, [liveDestinations, selectedDestination]);

  const loadNearbyBarriers = useCallback(async (location: [number, number]) => {
    try {
      const response = await fetch(`/api/barriers?lat=${location[0]}&lng=${location[1]}&radius=2500`, { cache: "no-store" });

      if (!response.ok) {
        return;
      }

      const payload = (await response.json()) as { barriers?: BarrierItem[] };
      setBarriers(payload.barriers ?? []);
    } catch {
      setAiAlert("Barrier feed unavailable right now. Retrying on next update.");
    }
  }, []);

  const fetchRealtimeDestinations = useCallback(
    async (query: string, location: [number, number]) => {
      const category = categoryFromQuery(query);
      const [lat, lng] = location;
      const searchQuery = query.trim();

      try {
        setIsAnalyzingDestination(true);
        setAiAlert(`AI analyzing nearby ${category} options in real time...`);

        const response = await fetch(`/api/places?query=${encodeURIComponent(searchQuery)}&lat=${lat}&lng=${lng}`, {
          cache: "no-store",
        });

        if (!response.ok) {
          throw new Error("Failed to fetch live places");
        }

        const payload = (await response.json()) as { places?: DestinationOption[] };
        const mapped = payload.places ?? [];

        if (mapped.length > 0) {
          setLiveDestinations(mapped);
          setAiAlert(`Found ${mapped.length} nearby ${category} places. Showing best options now.`);
          return mapped;
        } else {
          setLiveDestinations([]);
          setAiAlert(`No live ${category} places found around your location.`);
          return [];
        }
      } catch {
        setLiveDestinations([]);
        setAiAlert("Realtime place search unavailable. Check API key and network access.");
        return [];
      } finally {
        setIsAnalyzingDestination(false);
      }
    },
    [],
  );

  const fetchRouteForDestination = useCallback(
    async (destination: DestinationOption, modeForRoute: AccessibilityMode) => {
      try {
        const response = await fetch("/api/route", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            origin: currentLocation,
            destination: destination.position,
            mode: modeForRoute,
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch route");
        }

        const payload = (await response.json()) as {
          path?: [number, number][];
          summary?: RouteSummary;
        };

        setRoutePath(payload.path ?? []);
        setRouteSummary(payload.summary ?? { distanceMeters: 0, durationSeconds: 0 });
      } catch {
        setRoutePath([]);
        setRouteSummary({ distanceMeters: 0, durationSeconds: 0 });
        setAiAlert("Live route generation failed. Please verify Google API configuration.");
      }
    },
    [currentLocation],
  );

  const applyFallbackLocation = useCallback((message: string) => {
    setCurrentLocation(DEFAULT_MEXICO_LOCATION);
    setLocationStatus(message);
    void loadNearbyBarriers(DEFAULT_MEXICO_LOCATION);
  }, [loadNearbyBarriers]);

  const speak = useCallback((line: string) => {
    if (typeof window === "undefined") return;
    const synth = window.speechSynthesis;
    if (!synth) return;

    const utterance = new SpeechSynthesisUtterance(line);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.lang = "en-US";
    synth.cancel();
    synth.speak(utterance);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined" || !navigator.geolocation) {
      window.setTimeout(() => {
        applyFallbackLocation("GPS unavailable. Using Mexico City fallback location.");
      }, 0);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const nextLocation: [number, number] = [position.coords.latitude, position.coords.longitude];
        setCurrentLocation(nextLocation);
        setLocationStatus(`Realtime location detected: ${position.coords.latitude.toFixed(5)}, ${position.coords.longitude.toFixed(5)}`);
        void loadNearbyBarriers(nextLocation);
      },
      () => {
        applyFallbackLocation("Location permission denied. Using Mexico City fallback location.");
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 },
    );

    setAiAlert("Location ready. Type or speak a destination to begin realtime analysis.");
  }, [applyFallbackLocation, loadNearbyBarriers]);

  useEffect(() => {
    if (!reportSuccess) return;
    const timer = setTimeout(() => setReportSuccess(""), 3500);
    return () => clearTimeout(timer);
  }, [reportSuccess]);

  const pushAiLine = useCallback(
    (line: string) => {
      setConversation((prev) => [...prev.slice(-6), `AI: ${line}`]);
      setAiAlert(line);
      if (speechEnabled) speak(line);
    },
    [speechEnabled, speak],
  );

  const publishCommunityPost = useCallback(
    (post: CommunityPost) => {
      setCommunityPosts((prev) => [post, ...prev].slice(0, 6));
      setAiAlert(`Community awareness shared by ${post.author}.`);
      if (speechEnabled) {
        speak(`Community awareness shared by ${post.author}.`);
      }
    },
    [speechEnabled, speak],
  );

  const handleMicAction = () => {
    setThinking(true);
    setHazardPulse(false);

    window.setTimeout(() => {
      const line = hasRequestedDestination
        ? `Live status: ${barriers.length} reported barriers near route to ${selectedDestination.label}.`
        : "Live status: location ready. Say or type a destination to generate route.";
      pushAiLine(line);
      setThinking(false);
      if (line.toLowerCase().includes("barrier") || line.toLowerCase().includes("hazard")) {
        setHazardPulse(true);
      }
    }, 1100);
  };

  const chooseDestination = useCallback(
    async (query: string) => {
      if (!query.trim()) {
        setAiAlert("Please type or speak a destination such as pharmacy, hospital, metro, or park.");
        setHasRequestedDestination(false);
        return;
      }

      const realtimeOptions = await fetchRealtimeDestinations(query, currentLocation);
      const normalized = query.toLowerCase();
      const category = categoryFromQuery(query);
      const ranked = realtimeOptions
        .map((destination) => ({
          destination,
          distance: distanceKm(currentLocation, destination.position),
          categoryBoost: `${destination.label} ${destination.kind}`.toLowerCase().includes(category) ? 0 : 1,
          textBoost: destination.label.toLowerCase().includes(normalized) ? 0 : 1,
        }))
        .sort((a, b) => a.categoryBoost - b.categoryBoost || a.textBoost - b.textBoost || a.distance - b.distance);
      const destination = ranked[0]?.destination ?? resolveDestination(query);
      const km = distanceKm(currentLocation, destination.position);

      setHasRequestedDestination(true);
      setSelectedDestination(destination);
      await fetchRouteForDestination(destination, mode);
      await loadNearbyBarriers(currentLocation);
      setScreen("map");
      setDestinationQuery(query || destination.label);
      pushAiLine(`Nearest match found: ${destination.label} at ${km.toFixed(2)} km. Generating safest route now.`);
      pushAiLine(
        `Safety guide: follow the highlighted route, avoid 🚧 and 🚫 markers, and use the emoji destination marker for ${destination.label}.`,
      );
    },
    [currentLocation, fetchRealtimeDestinations, fetchRouteForDestination, loadNearbyBarriers, mode, pushAiLine, resolveDestination],
  );

  const startVoiceDestinationCapture = () => {
    const browserWindow = window as typeof window & {
      SpeechRecognition?: SpeechRecognitionCtor;
      webkitSpeechRecognition?: SpeechRecognitionCtor;
    };
    const SpeechRecognition = browserWindow.SpeechRecognition || browserWindow.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setAiAlert("Voice input is not supported in this browser. Use the search bar instead.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    setListening(true);
    setAiAlert("Listening for destination. Say pharmacy, hospital, metro, or park.");

    recognition.onresult = (event: SpeechRecognitionEventLike) => {
      const transcript = event.results[0]?.[0]?.transcript ?? "";
      setDestinationQuery(transcript);
      void chooseDestination(transcript);
      setListening(false);
    };

    recognition.onerror = () => {
      setListening(false);
      setAiAlert("Voice destination capture stopped. Please try the search bar.");
    };

    recognition.onend = () => {
      setListening(false);
    };

    recognition.start();
  };

  const submitBarrierReport = async (event: FormEvent) => {
    event.preventDefault();

    try {
      const response = await fetch("/api/barriers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: `Community report: ${reportCategory}`,
          type: reportCategory,
          position: currentLocation,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to submit barrier");
      }

      await loadNearbyBarriers(currentLocation);

      if (hasRequestedDestination) {
        await fetchRouteForDestination(selectedDestination, mode);
      }

      setReportSuccess("Barrier uploaded successfully. Live map and route data updated.");
      setHazardPulse(true);
      const communityPost: CommunityPost = {
        id: `${Date.now()}-community`,
        author: "Nearby user",
        message: `Hazard report: ${reportCategory}. Route updated for everyone nearby.`,
        label: reportCategory,
        tone: reportCategory.includes("unsafe") || reportCategory.includes("blocked") ? "danger" : "caution",
      };
      publishCommunityPost(communityPost);
      setAiAlert("Accessibility hazard reported nearby. Route updated automatically.");
      if (speechEnabled) {
        speak("Accessibility hazard reported nearby. Route updated automatically.");
      }
    } catch {
      setAiAlert("Barrier submission failed. Please retry.");
    }
  };

  const submitCommunityPost = (event: FormEvent) => {
    event.preventDefault();

    if (!communityMessage.trim()) return;

    publishCommunityPost({
      id: `${Date.now()}-broadcast`,
      author: communityAuthor.trim() || "Community member",
      message: communityMessage.trim(),
      label: "community awareness",
      tone: "safe",
    });
    setCommunityMessage("");
  };

  const shellClass =
    "relative min-h-screen overflow-hidden bg-slate-950 text-slate-100 selection:bg-cyan-300/40 selection:text-white";

  return (
    <div className={shellClass}>
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_10%_20%,rgba(40,255,200,0.2),transparent_45%),radial-gradient(circle_at_90%_15%,rgba(53,150,255,0.24),transparent_43%),radial-gradient(circle_at_50%_80%,rgba(16,95,120,0.2),transparent_45%)]" />
      <div className="grid-lines pointer-events-none absolute inset-0 opacity-30" />

      <header className="relative z-20 px-4 py-4 md:px-8">
        <div className="glass-panel mx-auto flex w-full max-w-7xl flex-wrap items-center justify-between gap-3 rounded-2xl px-4 py-3">
          <div>
            <p className="text-xs uppercase tracking-[0.45em] text-cyan-200/90">AccessGrid AI</p>
            <h1 className="font-display text-xl text-white md:text-2xl">AI Mobility Companion for Accessible Smart Cities</h1>
          </div>

          <nav className="flex flex-wrap gap-2">
            {navItems.map((item) => (
              <button
                key={item.key}
                onClick={() => {
                  setScreen(item.key);
                  if (item.key === "wheelchair") {
                    setMode("wheelchair");
                    if (hasRequestedDestination) {
                      void fetchRouteForDestination(selectedDestination, "wheelchair");
                    }
                  }
                  if (item.key === "elderly") {
                    setMode("elderly");
                    if (hasRequestedDestination) {
                      void fetchRouteForDestination(selectedDestination, "elderly");
                    }
                  }
                  if (item.key === "blind") {
                    setMode("blind");
                    if (hasRequestedDestination) {
                      void fetchRouteForDestination(selectedDestination, "blind");
                    }
                  }
                }}
                className={`rounded-full border px-4 py-2 text-xs uppercase tracking-[0.18em] transition ${
                  screen === item.key
                    ? "border-cyan-300 bg-cyan-200/20 text-cyan-50 shadow-[0_0_24px_rgba(44,232,255,0.35)]"
                    : "border-white/20 bg-white/5 text-slate-300 hover:border-cyan-200/60 hover:text-cyan-100"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="relative z-10 mx-auto flex w-full max-w-7xl flex-col gap-6 px-4 pb-8 md:px-8">
        <AnimatePresence mode="wait">
          {screen === "landing" && (
            <motion.section
              key="landing"
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.6 }}
              className="relative overflow-hidden rounded-3xl border border-cyan-200/20 bg-slate-900/55 p-6 backdrop-blur-xl md:p-10"
            >
              <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_15%_20%,rgba(49,255,184,0.12),transparent_50%),radial-gradient(circle_at_90%_40%,rgba(80,150,255,0.18),transparent_50%)]" />
              <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-cyan-500/10 to-transparent" />

              <div className="mb-8 flex flex-col gap-5 md:max-w-3xl">
                <motion.h2
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2, duration: 0.6 }}
                  className="font-display text-4xl leading-tight text-white sm:text-5xl md:text-6xl"
                >
                  AccessGrid AI
                </motion.h2>
                <motion.p
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                  className="max-w-2xl text-base text-slate-200/90 md:text-lg"
                >
                  A cinematic AI operating layer for accessible mobility. Voice-guided navigation, real-time obstacle intelligence,
                  and community-powered hazard mapping in one premium interface.
                </motion.p>
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  whileHover={{ scale: 1.05 }}
                  onClick={handleMicAction}
                  className="pulse-glow flex h-20 w-20 items-center justify-center rounded-full border border-cyan-200/70 bg-cyan-300/20 text-2xl text-cyan-50"
                  aria-label="Activate AI microphone"
                >
                  MIC
                </motion.button>
              </div>

              <div className="grid gap-4 md:grid-cols-4">
                {featureCards.map((card, index) => (
                  <motion.article
                    key={card}
                    initial={{ opacity: 0, y: 24 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.38 + index * 0.08, duration: 0.45 }}
                    className="glass-panel rounded-2xl border border-white/15 p-4"
                  >
                    <p className="text-sm text-cyan-100">{card}</p>
                  </motion.article>
                ))}
              </div>

              <div className="mt-8 grid gap-3 md:grid-cols-3">
                {statTargets.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, scale: 0.94 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
                    className="rounded-2xl border border-cyan-100/20 bg-black/25 px-4 py-5"
                  >
                    <p className="font-display text-2xl text-cyan-100">{stat.value.toLocaleString()}</p>
                    <p className="mt-2 text-xs uppercase tracking-[0.2em] text-slate-300">{stat.label}</p>
                  </motion.div>
                ))}
              </div>
            </motion.section>
          )}

          {screen === "blind" && (
            <motion.section
              key="blind"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="relative overflow-hidden rounded-3xl border border-cyan-200/30 bg-black/50 p-4 md:p-6"
            >
              <div className="mb-4 grid gap-3 md:grid-cols-4">
                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">AI Status</p>
                  <p className="mt-2 text-cyan-100">{thinking ? "Thinking..." : "Live Guidance Active"}</p>
                </div>
                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Destination</p>
                  <p className="mt-2 text-cyan-100">{selectedDestination.label}</p>
                </div>
                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Mode</p>
                  <p className="mt-2 text-cyan-100">Blind Voice Assist</p>
                </div>
                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Safety Score</p>
                  <p className="mt-2 text-cyan-100">{safetyScore}%</p>
                </div>
              </div>

              <div className="relative h-[55vh] overflow-hidden rounded-2xl border border-cyan-100/30 bg-[linear-gradient(140deg,rgba(3,19,38,0.95),rgba(9,34,55,0.85),rgba(14,28,39,0.95))]">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_40%_20%,rgba(55,198,255,0.18),transparent_38%),radial-gradient(circle_at_80%_70%,rgba(46,255,180,0.15),transparent_40%)]" />

                <div className="absolute left-4 top-4 right-4 grid gap-2 md:grid-cols-2">
                  {barriers.slice(0, 4).map((barrier) => (
                    <div key={`blind-${barrier.id}`} className={`rounded-xl border p-2 ${severityStyle[barrier.severity]}`}>
                      <p className="text-xs uppercase tracking-[0.15em]">
                        {barrierSymbol(barrier.type)} {barrier.title}
                      </p>
                    </div>
                  ))}
                  {barriers.length === 0 && (
                    <div className="rounded-xl border border-cyan-200/40 bg-cyan-200/10 p-3 text-xs text-cyan-100">
                      No live barriers nearby yet. Submit a report to populate real-time hazard feed.
                    </div>
                  )}
                </div>

                {hazardPulse && (
                  <motion.div
                    initial={{ opacity: 0.7, scale: 0.9 }}
                    animate={{ opacity: 0, scale: 1.2 }}
                    transition={{ duration: 1.2, repeat: Infinity }}
                    className="absolute inset-0 border-2 border-rose-300"
                  />
                )}

                <div className="absolute inset-x-3 bottom-3 rounded-xl border border-cyan-100/30 bg-slate-950/65 p-4 backdrop-blur-md">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Live Subtitles</p>
                  <p className="mt-2 text-sm text-slate-100">{aiAlert}</p>
                </div>
              </div>

              <div className="mt-4 grid gap-4 md:grid-cols-[auto_1fr]">
                <button
                  onClick={handleMicAction}
                  className="pulse-glow flex h-20 w-20 items-center justify-center rounded-full border border-cyan-300/80 bg-cyan-300/20 text-3xl text-cyan-50"
                >
                  MIC
                </button>
                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">AI Conversation Stream</p>
                  <div className="mt-2 space-y-2 text-sm text-slate-100">
                    {conversation.slice(-4).map((line, index) => (
                      <p key={`${line}-${index}`}>{line}</p>
                    ))}
                  </div>
                </div>
              </div>
            </motion.section>
          )}

          {(screen === "map" || screen === "wheelchair" || screen === "elderly") && (
            <motion.section
              key="map-family"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="grid gap-4 lg:grid-cols-[1fr_320px]"
            >
              <div className="relative h-[70vh] overflow-hidden rounded-3xl border border-cyan-200/20">
                <div className="absolute inset-0 z-[500] pointer-events-none bg-[radial-gradient(circle_at_15%_15%,rgba(25,255,200,0.08),transparent_35%),radial-gradient(circle_at_80%_70%,rgba(50,120,255,0.15),transparent_40%)]" />
                {hasRequestedDestination && CityAccessibilityMap ? (
                  <CityAccessibilityMap mode={mode} barriers={barriers} destination={selectedDestination} currentLocation={currentLocation} routePath={routePath} />
                ) : hasRequestedDestination ? (
                  <div className="flex h-full items-center justify-center bg-[radial-gradient(circle_at_center,rgba(27,58,89,0.5),rgba(4,10,19,0.92))] p-8 text-center">
                    <div className="max-w-md rounded-3xl border border-cyan-200/20 bg-slate-950/60 p-6 backdrop-blur-md">
                      <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Loading Live Map</p>
                      <p className="mt-3 text-lg text-slate-100">Preparing the realtime accessibility map and route overlay.</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex h-full items-center justify-center bg-[radial-gradient(circle_at_center,rgba(27,58,89,0.5),rgba(4,10,19,0.92))] p-8 text-center">
                    <div className="max-w-md rounded-3xl border border-cyan-200/20 bg-slate-950/60 p-6 backdrop-blur-md">
                      <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Realtime Map Ready</p>
                      <p className="mt-3 text-lg text-slate-100">Type a destination or use voice search to start live place analysis and show the safest route.</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Choose Destination</p>
                  <p className="mt-2 text-sm text-slate-100">Say or type your destination. Example: I need pharmacy.</p>
                  <p className="mt-2 text-xs text-cyan-100">📍 {locationStatus}</p>
                  <p className="mt-1 text-xs text-emerald-200">
                    {isAnalyzingDestination ? "🤖 AI analyzing nearby places in realtime..." : "✅ Realtime nearby places loaded"}
                  </p>
                  <form
                    className="mt-3 flex gap-2"
                    onSubmit={(event) => {
                      event.preventDefault();
                      void chooseDestination(destinationQuery);
                    }}
                  >
                    <input
                      value={destinationQuery}
                      onChange={(event) => setDestinationQuery(event.target.value)}
                      className="min-w-0 flex-1 rounded-xl border border-white/15 bg-slate-900/70 px-3 py-3 text-sm text-slate-100 outline-none placeholder:text-slate-500"
                      placeholder="Search destination..."
                      aria-label="Search destination"
                    />
                    <button
                      type="button"
                      onClick={startVoiceDestinationCapture}
                      className={`rounded-xl border px-4 py-3 text-xs uppercase tracking-[0.18em] transition ${
                        listening
                          ? "border-emerald-300/80 bg-emerald-300/20 text-emerald-50"
                          : "border-cyan-200/70 bg-cyan-200/15 text-cyan-50"
                      }`}
                    >
                      {listening ? "Listening" : "Voice"}
                    </button>
                  </form>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {["pharmacy", "hospital", "metro", "park"].map((category) => (
                      <button
                        key={category}
                        type="button"
                        onClick={() => void chooseDestination(category)}
                        className={`rounded-full border px-3 py-2 text-xs uppercase tracking-[0.15em] transition ${
                          destinationQuery.toLowerCase().includes(category)
                            ? "border-cyan-300 bg-cyan-200/15 text-cyan-50"
                            : "border-white/15 bg-white/5 text-slate-200 hover:border-cyan-200/60"
                        }`}
                      >
                        {category === "pharmacy" ? "💊" : category === "hospital" ? "🏥" : category === "metro" ? "🚇" : "🌳"} {category}
                      </button>
                    ))}
                  </div>
                  <div className="mt-3 grid gap-2">
                    {(hasRequestedDestination ? nearbyMatches : []).map(({ destination, distance }, index) => (
                      <button
                        key={destination.id}
                        onClick={() => void chooseDestination(destination.label)}
                        className={`rounded-xl border px-3 py-3 text-left transition ${
                          selectedDestination.id === destination.id
                            ? "border-cyan-300 bg-cyan-200/15 text-cyan-50 shadow-[0_0_18px_rgba(44,232,255,0.2)]"
                            : "border-white/15 bg-white/5 text-slate-200 hover:border-cyan-200/60"
                        }`}
                      >
                        <p className="text-sm font-medium">{destinationSymbol(destination)} {destination.label}</p>
                        <p className="text-xs text-slate-300">{destination.kind} • {distance.toFixed(2)} km away</p>
                        {index === 0 && <p className="mt-1 text-[11px] text-emerald-200">✅ Best nearby match</p>}
                      </button>
                    ))}
                    {!hasRequestedDestination && (
                      <div className="rounded-xl border border-white/10 bg-black/20 px-4 py-5 text-sm text-slate-300">
                        No nearby places shown yet. Submit a destination like <span className="text-cyan-100">pharmacy</span> or use voice search.
                      </div>
                    )}
                  </div>
                </div>

                {hasRequestedDestination && <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">AI Route Assistant</p>
                  <p className="mt-3 text-sm text-slate-100">{modeLabel[mode]}</p>
                  <p className="mt-2 text-xs text-slate-300">{selectedDestination.hint}</p>
                  <p className="mt-2 text-xs text-cyan-100">Nearest accessible: {destinationSymbol(selectedDestination)} {selectedDestination.label}</p>
                  <div className="mt-4 space-y-2 rounded-xl border border-cyan-200/15 bg-black/20 p-3 text-xs text-slate-200">
                    <p className="uppercase tracking-[0.2em] text-cyan-100">Route Analysis</p>
                    {routeAnalysis.map((item) => (
                      <p key={item}>• {item}</p>
                    ))}
                  </div>
                  <div className="mt-3 space-y-2 rounded-xl border border-emerald-200/15 bg-emerald-400/10 p-3 text-xs text-emerald-50">
                    <p className="uppercase tracking-[0.2em] text-emerald-100">Safety Guide</p>
                    {safetyGuidelines.map((item) => (
                      <p key={item}>• {item}</p>
                    ))}
                  </div>
                </div>}

                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Safety Alerts</p>
                  <p className="mt-3 text-sm text-slate-100">{aiAlert}</p>
                </div>

                {hasRequestedDestination && <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Blocked Places & Challenges</p>
                  <p className="mt-2 text-xs text-slate-300">Emoji markers show blocked ramps, road issues, and hazards near your route.</p>
                  <div className="mt-3 space-y-3 text-sm text-slate-100">
                    {barriers.slice(0, 3).map((barrier) => (
                      <div key={barrier.id} className="rounded-xl border border-white/10 bg-black/20 px-3 py-3">
                        <p className="font-medium">{barrierSymbol(barrier.type)} {barrier.title}</p>
                        <p className="mt-1 text-xs lowercase text-slate-400">{barrier.type}</p>
                      </div>
                    ))}
                  </div>
                </div>}

                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Community Board</p>
                  <p className="mt-2 text-sm text-slate-300">People can warn each other in real time about routes, barriers, and safe entrances.</p>
                  <form onSubmit={submitCommunityPost} className="mt-3 space-y-3">
                    <input
                      value={communityAuthor}
                      onChange={(event) => setCommunityAuthor(event.target.value)}
                      className="w-full rounded-xl border border-white/15 bg-slate-900/70 px-3 py-3 text-sm text-slate-100 outline-none"
                      placeholder="Your name"
                    />
                    <textarea
                      value={communityMessage}
                      onChange={(event) => setCommunityMessage(event.target.value)}
                      rows={3}
                      className="w-full rounded-xl border border-white/15 bg-slate-900/70 px-3 py-3 text-sm text-slate-100 outline-none"
                      placeholder="Share an accessibility awareness update"
                    />
                    <button
                      type="submit"
                      className="w-full rounded-xl border border-emerald-300/70 bg-emerald-300/15 px-4 py-3 text-xs uppercase tracking-[0.2em] text-emerald-50 transition hover:bg-emerald-300/25"
                    >
                      Broadcast awareness
                    </button>
                  </form>
                  <div className="mt-4 space-y-3">
                    {communityPosts.slice(0, 3).map((post) => (
                      <div key={post.id} className="rounded-xl border border-white/10 bg-black/20 p-3">
                        <div className="flex items-center justify-between gap-3">
                          <p className="text-sm text-white">{post.author}</p>
                          <span className={`rounded-full border px-2 py-1 text-[10px] uppercase tracking-[0.18em] ${severityStyle[post.tone]}`}>
                            {communityToneEmoji[post.tone]} {post.label}
                          </span>
                        </div>
                        <p className="mt-2 text-xs leading-5 text-slate-300">{post.message}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {hasRequestedDestination && <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Route Difficulty Analyzer</p>
                  <p className="mt-2 text-xs text-slate-300">Compares route challenge level and picks the best route for your mode.</p>
                  <div className="mt-3 space-y-2">
                    {routeOptions.routes.map((route) => {
                      const difficultyColor =
                        route.difficulty === "easy"
                          ? "border-emerald-300/50 bg-emerald-300/10 text-emerald-100"
                          : route.difficulty === "moderate"
                            ? "border-yellow-300/50 bg-yellow-300/10 text-yellow-100"
                            : "border-rose-300/50 bg-rose-300/10 text-rose-100";
                      const difficultyEmoji =
                        route.difficulty === "easy" ? "🟢" : route.difficulty === "moderate" ? "🟡" : "🔴";

                      return (
                        <div key={route.id} className={`rounded-xl border px-3 py-2 ${difficultyColor}`}>
                          <p className="text-sm font-medium">{difficultyEmoji} {route.name}</p>
                          <p className="text-xs">{route.distanceKm.toFixed(2)} km • {route.difficulty}</p>
                          <p className="mt-1 text-[11px] opacity-90">{route.reason}</p>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-3 rounded-xl border border-cyan-200/40 bg-cyan-200/10 p-3">
                    <p className="text-xs uppercase tracking-[0.18em] text-cyan-100">Best Route To Reach Destination</p>
                    <p className="mt-1 text-sm text-cyan-50">✅ {routeOptions.best.name}</p>
                    <p className="text-xs text-cyan-100/90">
                      Recommended because it offers the safest balance of lower challenge risk and stable accessibility access.
                    </p>
                  </div>
                </div>}

                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Mode Controls</p>
                  <div className="mt-3 grid gap-2">
                    <button
                      onClick={() => {
                        setMode("blind");
                        setScreen("map");
                        if (hasRequestedDestination) {
                          void fetchRouteForDestination(selectedDestination, "blind");
                        }
                        pushAiLine("Blind user route optimized with voice obstacle warnings.");
                      }}
                      className="rounded-xl border border-white/20 px-3 py-2 text-left text-sm text-slate-200 hover:border-cyan-200/80"
                    >
                      Blind Mode
                    </button>
                    <button
                      onClick={() => {
                        setMode("wheelchair");
                        setScreen("wheelchair");
                        if (hasRequestedDestination) {
                          void fetchRouteForDestination(selectedDestination, "wheelchair");
                        }
                        pushAiLine("Alternative wheelchair-accessible route available.");
                      }}
                      className="rounded-xl border border-white/20 px-3 py-2 text-left text-sm text-slate-200 hover:border-cyan-200/80"
                    >
                      Wheelchair Priority
                    </button>
                    <button
                      onClick={() => {
                        setMode("elderly");
                        setScreen("elderly");
                        if (hasRequestedDestination) {
                          void fetchRouteForDestination(selectedDestination, "elderly");
                        }
                        pushAiLine("Safer low-traffic route recommended.");
                      }}
                      className="rounded-xl border border-white/20 px-3 py-2 text-left text-sm text-slate-200 hover:border-cyan-200/80"
                    >
                      Elderly Safety Mode
                    </button>
                  </div>
                </div>
              </div>
            </motion.section>
          )}

          {screen === "report" && (
            <motion.section
              key="report"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="grid gap-4 lg:grid-cols-[1fr_320px]"
            >
              <form onSubmit={submitBarrierReport} className="glass-panel rounded-3xl p-6">
                <h3 className="font-display text-3xl text-white">Community Barrier Reporting</h3>
                <p className="mt-2 text-sm text-slate-300">Upload hazard evidence, auto-tag GPS, and trigger real-time accessibility route updates.</p>

                <label className="mt-6 flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-cyan-200/45 bg-cyan-200/5 p-10 text-center">
                  <span className="text-sm text-cyan-100">Drag and drop image upload</span>
                  <span className="mt-2 text-xs text-slate-400">PNG / JPG - simulate street barrier evidence</span>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={(event) => {
                      const file = event.target.files?.[0] ?? null;
                      setReportFile(file);
                    }}
                  />
                </label>

                <div className="mt-5 grid gap-4 md:grid-cols-2">
                  <div>
                    <p className="mb-2 text-xs uppercase tracking-[0.2em] text-slate-400">Issue Category</p>
                    <select
                      value={reportCategory}
                      onChange={(event) => setReportCategory(event.target.value as ReportCategory)}
                      className="w-full rounded-xl border border-white/20 bg-slate-900/70 px-3 py-3 text-sm text-slate-100 outline-none"
                    >
                      {reportCategories.map((category) => (
                        <option key={category} value={category}>
                          {reportEmoji[category]} {category}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <p className="mb-2 text-xs uppercase tracking-[0.2em] text-slate-400">GPS Auto-Location</p>
                    <div className="rounded-xl border border-white/20 bg-slate-900/70 px-3 py-3 text-sm text-slate-200">
                      Lat {currentLocation[0].toFixed(5)} | Lng {currentLocation[1].toFixed(5)}
                    </div>
                  </div>
                </div>

                <p className="mt-4 text-xs text-slate-400">Selected file: {reportFile?.name ?? "No image selected"}</p>

                <button
                  type="submit"
                  className="mt-5 rounded-xl border border-cyan-200/80 bg-cyan-200/20 px-5 py-3 text-sm uppercase tracking-[0.2em] text-cyan-50 transition hover:bg-cyan-200/30"
                >
                  🚧 Submit Live Barrier Report
                </button>

                <AnimatePresence>
                  {reportSuccess && (
                    <motion.p
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      className="mt-4 rounded-xl border border-emerald-300/50 bg-emerald-400/15 p-3 text-sm text-emerald-100"
                    >
                      {reportSuccess}
                    </motion.p>
                  )}
                </AnimatePresence>
              </form>

              <div className="space-y-4">
                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-cyan-200">Realtime City Update System</p>
                  <p className="mt-2 text-sm text-slate-100">🛰️ Markers appear instantly, routes update dynamically, and AI voice warning broadcasts across nearby users.</p>
                </div>

                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-cyan-200">Community Awareness Board</p>
                  <p className="mt-2 text-sm text-slate-300">👥 Reports and helpful tips from nearby citizens are broadcast to everyone navigating the city.</p>
                </div>

                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-cyan-200">Latest AI Broadcast</p>
                  <p className="mt-2 text-sm text-slate-100">📣 {aiAlert}</p>
                </div>

                <div className="glass-panel rounded-2xl p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-cyan-200">Live Barrier Feed</p>
                  <div className="mt-2 space-y-2 text-xs text-slate-200">
                    {barriers.slice(0, 4).map((barrier) => (
                      <p key={barrier.id}>{barrierSymbol(barrier.type)} {barrier.title}</p>
                    ))}
                  </div>
                </div>
              </div>
            </motion.section>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
