export type AccessibilityMode = "blind" | "wheelchair" | "elderly";

export type DestinationOption = {
  id: string;
  label: string;
  kind: string;
  position: [number, number];
  hint: string;
  placeId?: string;
};

export type BarrierItem = {
  id: string;
  title: string;
  type: string;
  severity: "safe" | "caution" | "danger";
  position: [number, number];
  reportedAt: string;
};

export type RouteSummary = {
  distanceMeters: number;
  durationSeconds: number;
};
