const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;

export const hasGoogleMapsKey = () => Boolean(GOOGLE_MAPS_API_KEY);

export const requireGoogleMapsKey = () => {
  if (!GOOGLE_MAPS_API_KEY) {
    throw new Error("Missing GOOGLE_MAPS_API_KEY");
  }

  return GOOGLE_MAPS_API_KEY;
};
