import type { BarrierItem } from "@/types/accessibility";

const barriers: BarrierItem[] = [];

const toRadians = (value: number) => (value * Math.PI) / 180;

const distanceMeters = (from: [number, number], to: [number, number]) => {
  const earthRadius = 6371000;
  const dLat = toRadians(to[0] - from[0]);
  const dLng = toRadians(to[1] - from[1]);
  const lat1 = toRadians(from[0]);
  const lat2 = toRadians(to[0]);

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return earthRadius * c;
};

export const getBarriers = (center?: [number, number], radiusMeters = 2500) => {
  if (!center) {
    return barriers;
  }

  return barriers.filter((barrier) => distanceMeters(center, barrier.position) <= radiusMeters);
};

export const addBarrier = (barrier: Omit<BarrierItem, "id" | "reportedAt">) => {
  const item: BarrierItem = {
    ...barrier,
    id: crypto.randomUUID(),
    reportedAt: new Date().toISOString(),
  };

  barriers.unshift(item);
  return item;
};
