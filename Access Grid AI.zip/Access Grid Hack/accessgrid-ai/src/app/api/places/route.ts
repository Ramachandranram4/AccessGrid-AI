import { NextResponse } from "next/server";
import { requireGoogleMapsKey } from "@/lib/google";
import type { DestinationOption } from "@/types/accessibility";

const parseNumber = (value: string | null, fallback: number) => {
  const parsed = value ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : fallback;
};

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const query = url.searchParams.get("query")?.trim();

    if (!query) {
      return NextResponse.json({ error: "Missing query" }, { status: 400 });
    }

    const lat = parseNumber(url.searchParams.get("lat"), 19.4326);
    const lng = parseNumber(url.searchParams.get("lng"), -99.1332);
    const key = requireGoogleMapsKey();

    const searchUrl = new URL("https://maps.googleapis.com/maps/api/place/textsearch/json");
    searchUrl.searchParams.set("query", query);
    searchUrl.searchParams.set("location", `${lat},${lng}`);
    searchUrl.searchParams.set("radius", "5000");
    searchUrl.searchParams.set("language", "en");
    searchUrl.searchParams.set("key", key);

    const response = await fetch(searchUrl.toString(), {
      cache: "no-store",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      return NextResponse.json({ error: "Google Places request failed" }, { status: 502 });
    }

    const payload = (await response.json()) as {
      status?: string;
      results?: Array<{
        place_id: string;
        name: string;
        formatted_address?: string;
        types?: string[];
        geometry?: {
          location?: {
            lat: number;
            lng: number;
          };
        };
      }>;
    };

    if (!payload.results || payload.results.length === 0) {
      return NextResponse.json({ places: [] as DestinationOption[] });
    }

    const places = payload.results
      .map((result) => {
        const placeLat = result.geometry?.location?.lat;
        const placeLng = result.geometry?.location?.lng;

        if (!Number.isFinite(placeLat) || !Number.isFinite(placeLng)) {
          return null;
        }

        return {
          id: result.place_id,
          placeId: result.place_id,
          label: result.name,
          kind: result.types?.[0]?.replaceAll("_", " ") ?? "destination",
          position: [placeLat, placeLng] as [number, number],
          hint: result.formatted_address ?? "Google Places result",
        } satisfies DestinationOption;
      })
      .filter((place): place is DestinationOption => Boolean(place));

    return NextResponse.json({ places });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unexpected error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
