import { NextResponse } from "next/server";
import { requireGoogleMapsKey } from "@/lib/google";
import { decodePolyline } from "@/lib/polyline";
import type { AccessibilityMode } from "@/types/accessibility";

type RouteBody = {
  origin: [number, number];
  destination: [number, number];
  mode: AccessibilityMode;
};

const validatePoint = (value: unknown): value is [number, number] => {
  return (
    Array.isArray(value) &&
    value.length === 2 &&
    Number.isFinite(value[0]) &&
    Number.isFinite(value[1])
  );
};

const chooseRoute = (
  routes: Array<{
    overview_polyline?: { points?: string };
    legs?: Array<{ distance?: { value?: number }; duration?: { value?: number }; steps?: unknown[] }>;
  }>,
  mode: AccessibilityMode,
) => {
  if (routes.length === 0) {
    return null;
  }

  if (mode === "blind") {
    return routes[0];
  }

  const scored = routes.map((route) => {
    const leg = route.legs?.[0];
    const distance = leg?.distance?.value ?? Number.MAX_SAFE_INTEGER;
    const duration = leg?.duration?.value ?? Number.MAX_SAFE_INTEGER;
    const steps = leg?.steps?.length ?? 0;

    const score =
      mode === "wheelchair"
        ? distance * 0.6 + duration * 0.3 + steps * 120
        : distance * 0.4 + duration * 0.5 + steps * 80;

    return { route, score };
  });

  scored.sort((a, b) => a.score - b.score);
  return scored[0]?.route ?? routes[0];
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as RouteBody;

    if (!validatePoint(body.origin) || !validatePoint(body.destination)) {
      return NextResponse.json({ error: "Invalid origin or destination" }, { status: 400 });
    }

    const key = requireGoogleMapsKey();

    const url = new URL("https://maps.googleapis.com/maps/api/directions/json");
    url.searchParams.set("origin", `${body.origin[0]},${body.origin[1]}`);
    url.searchParams.set("destination", `${body.destination[0]},${body.destination[1]}`);
    url.searchParams.set("mode", "walking");
    url.searchParams.set("alternatives", "true");
    url.searchParams.set("language", "en");
    url.searchParams.set("key", key);

    const response = await fetch(url.toString(), { cache: "no-store" });

    if (!response.ok) {
      return NextResponse.json({ error: "Google Directions request failed" }, { status: 502 });
    }

    const payload = (await response.json()) as {
      status?: string;
      routes?: Array<{
        overview_polyline?: { points?: string };
        legs?: Array<{ distance?: { value?: number }; duration?: { value?: number }; steps?: unknown[] }>;
      }>;
    };

    const routes = payload.routes ?? [];
    const selected = chooseRoute(routes, body.mode);

    if (!selected) {
      return NextResponse.json({ error: "No route found" }, { status: 404 });
    }

    const encoded = selected.overview_polyline?.points;

    if (!encoded) {
      return NextResponse.json({ error: "Route polyline missing" }, { status: 502 });
    }

    const path = decodePolyline(encoded);
    const leg = selected.legs?.[0];

    return NextResponse.json({
      path,
      summary: {
        distanceMeters: leg?.distance?.value ?? 0,
        durationSeconds: leg?.duration?.value ?? 0,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unexpected error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
