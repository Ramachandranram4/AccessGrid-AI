import { NextResponse } from "next/server";
import { addBarrier, getBarriers } from "@/lib/barrierStore";

const parseNumber = (value: string | null, fallback: number) => {
  const parsed = value ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : fallback;
};

const severityFromType = (type: string) => {
  const normalized = type.toLowerCase();

  if (normalized.includes("blocked") || normalized.includes("unsafe") || normalized.includes("construction")) {
    return "danger" as const;
  }

  if (normalized.includes("safe")) {
    return "safe" as const;
  }

  return "caution" as const;
};

export async function GET(request: Request) {
  const url = new URL(request.url);
  const lat = parseNumber(url.searchParams.get("lat"), NaN);
  const lng = parseNumber(url.searchParams.get("lng"), NaN);
  const radius = parseNumber(url.searchParams.get("radius"), 2500);

  const center = Number.isFinite(lat) && Number.isFinite(lng) ? ([lat, lng] as [number, number]) : undefined;

  return NextResponse.json({ barriers: getBarriers(center, radius) });
}

export async function POST(request: Request) {
  const body = (await request.json()) as {
    title?: string;
    type?: string;
    position?: [number, number];
  };

  const type = body.type?.trim();
  const title = body.title?.trim() || "Community report";

  if (!type) {
    return NextResponse.json({ error: "Barrier type is required" }, { status: 400 });
  }

  if (!Array.isArray(body.position) || body.position.length !== 2) {
    return NextResponse.json({ error: "Barrier position is required" }, { status: 400 });
  }

  const [lat, lng] = body.position;

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return NextResponse.json({ error: "Barrier position is invalid" }, { status: 400 });
  }

  const barrier = addBarrier({
    title,
    type,
    severity: severityFromType(type),
    position: [lat, lng],
  });

  return NextResponse.json({ barrier }, { status: 201 });
}
