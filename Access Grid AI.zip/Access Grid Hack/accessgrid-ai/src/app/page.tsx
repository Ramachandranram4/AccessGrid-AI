import AccessGridExperience from "@/components/AccessGridExperience";

export default function Home() {
  return <AccessGridExperience />;
}
