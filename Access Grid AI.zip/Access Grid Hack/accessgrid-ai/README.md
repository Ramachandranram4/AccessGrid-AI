# AccessGrid AI

AccessGrid AI is a Next.js app with a real frontend + backend flow for accessible mobility routing.

## What Is Real-Time Now

- Destination search uses Google Places through backend API route `GET /api/places`.
- Route generation uses Google Directions through backend API route `POST /api/route`.
- Barrier reporting is handled by backend API route `GET/POST /api/barriers`.
- Frontend map renders real route polylines and live barriers from backend responses.

## Environment Variables

Copy `.env.example` to `.env.local` and set your key:

```bash
cp .env.example .env.local
```

Required variable:

- `GOOGLE_MAPS_API_KEY`: server-side key used in API routes.

Google APIs that should be enabled:

- Places API
- Directions API

## Project Structure

```txt
src/
	app/
		api/
			places/route.ts      # Google Places proxy
			route/route.ts       # Google Directions proxy + polyline decoding
			barriers/route.ts    # Barrier feed + report endpoint
		page.tsx
	components/
		AccessGridExperience.tsx
		CityAccessibilityMap.tsx
	lib/
		google.ts              # Env key loading
		polyline.ts            # Google polyline decoder
		barrierStore.ts        # In-memory barrier store
	types/
		accessibility.ts
```

## Run Locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Notes

- Barrier storage is currently in-memory for now (resets on server restart).
- If you need persistence, connect `src/lib/barrierStore.ts` to a database (PostgreSQL, MongoDB, Firestore, etc.).
